import { Injectable } from '@angular/core';

import { Jsonp } from '@angular/http';
import { Observable } from 'rxjs/Observable'; // Map
// import 'rxjs/Rx'; esto deberia ser el map, pero no me funciona y por eso puse lo de arriba, pero no se si esta bien

@Injectable()
export class PeliculasService {

  private apikey = '73748587222303dc1a1a93a01b5e15d1';
  private urlMoviedb = 'https://api.themoviedb.org/3';

  peliculas: any[] = [];

  constructor( private jsonp: Jsonp ) { }

  getCartelera() {

    let desde = new Date();
    let hasta = new Date();

    hasta.setDate( hasta.getDate() + 7);

    let desdeStr = `${ desde.getFullYear() }-${ desde.getMonth() + 1 }-${ desde.getDate() }`;
    let hastaStr = `${ hasta.getFullYear() }-${ hasta.getMonth() + 1 }-${ hasta.getDate() }`;


    let url = `${ this.urlMoviedb }//discover/movie?primary_release_date.gte=${ desdeStr }&primary_release_date.lte=${ hastaStr }
    &api_key=${ this.apikey }&language=es&callback=JSONP_CALLBACK`;

    return this.jsonp.get( url )
                .map( res => res.json().results );

  }

  getPopulares() {

    let url = `${ this.urlMoviedb }/discover/movie?sort_by=popularity.desc&api_key=${ this.apikey }&language=es&callback=JSONP_CALLBACK`;

    return this.jsonp.get( url )
                .map( res => res.json().results );
  }

  getPopularesNinos() {

    let url = `${ this.urlMoviedb } /discover/movie?certification_country=US&certification.lte=G&sort_by=popularity.desc
    &api_key=${ this.apikey }&language=es&callback=JSONP_CALLBACK`;

    return this.jsonp.get( url )
                .map( res => res.json().results );
  }

  buscarPelicula( texto: string ) {

    let url = `${ this.urlMoviedb }/search/movie?query=${ texto }
    &sort_by=popularity.desc&api_key=${ this.apikey }&language=es&callback=JSONP_CALLBACK`;


    return this.jsonp.get( url )
                .map( res => {
                  this.peliculas = res.json().results;
                  return res.json().results });
  }

  getPelicula( id: string ) {

    let url = `${ this.urlMoviedb } /movie/${ id }
    ?api_key=${ this.apikey }&language=es&callback=JSONP_CALLBACK`;

    return this.jsonp.get( url )
                .map( res => res.json() );
  }

}

